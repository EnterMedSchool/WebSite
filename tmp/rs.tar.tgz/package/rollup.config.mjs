import getRollupConfig from '../../rollup.base.mjs';

export default getRollupConfig('core');
